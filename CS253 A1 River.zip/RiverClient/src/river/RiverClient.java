/**
 * @author Benjamin Sampson
 * 914545
 *
 * Java client that runs the RiverServer program. This contains information on how
 * to navigate and use the program.
 */
package river;

import river.RiverServer;
import river.RiverServerService;
import java.util.Scanner;

public class RiverClient {

    /**
     * Main method of the client
     *
     * @param args
     */
    public static void main(String[] args) {
        //Links RiverServer to the client
        RiverServerService service = new RiverServerService();
        RiverServer port = service.getRiverServerPort();
        Scanner in = new Scanner(System.in); //Makes a new scanner

        //Prints out a list of possible commands the user can do
        System.out.println("To add a river: addRiver \n"
                + "To make a tributary: makeTributary \n"
                + "To update river length: updateRiverLength \n"
                + "To search for a river using length: searchRivers \n"
                + "To call all rivers: callRivers \n"
                + "Exit program: exit \n"
                + "Please pick an option above: ");

        Boolean exit = false; //Exit of program is false so it doenst close instantly

        while (exit != true) { //While exit does not equal true
            if (!in.equals("")) { //If the input is not empty
                String menu; //Make a new string
                menu = in.next(); //Make a new input
                try {
                    switch (menu) { //Provides a case statement for the user inputted commands
                        case "addRiver": //Case to add a river using user inputs
                            System.out.println("Please add a river: ");
                            String riverName = in.next(); //Takes in a riverName
                            System.out.println("Enter length");
                            int length = in.nextInt(); //Takes in a river length
                            System.out.println("River added");
                            port.addRiver(riverName, length); //Adds the name and length to the server
                            break;
                        case "makeTributary": //Case to make a tributary using user inputs
                            System.out.println("Please make tributary rivers: \n"
                                    + port.allRiversToString()); //Displays all currently made rivers
                            riverName = in.next(); //Takes in a riverName
                            String riverName2 = in.next(); //Takes in the name of a second river
                            if (riverName == riverName) { //If statement to make sure both rivers are different
                                System.out.println("Error making tribautary"); //Throws error if both rivers have same name
                            } else {
                                System.out.println("Tributary made");
                                port.makeTributary(riverName, riverName2); //Makes a tributary of both rivers
                            }
                            break;
                        case "updateRiverLength": //Case to update river length using user inputs
                            System.out.println("Please choose a river to update: \n"
                                    + port.allRiversToString()); //Displays all currently made rivers
                            riverName = in.next(); //Takes in a riverName
                            System.out.println("New length: ");
                            length = in.nextInt(); //Takes in the length of a river
                            System.out.println("Length updated");
                            port.updateRiverLength(riverName, length);//Updates the river with a new length
                            break;
                        case "searchRiver": //Case to call a river by name
                            System.out.println("Enter river length: ");
                            length = in.nextInt(); //Takes in a riverName
                            System.out.println(port.searchRivers(length)); //Displays the river that the user asked for
                            break;
                        case "callRivers": //Case to call all rivers made by the user
                            System.out.println(port.allRiversToString()); //Displays all rivers made by the user
                            break;
                        case "exit": //Case to exit the programs
                            System.out.println("Program closing.");
                            in.close(); //Closes the scanner
                            exit = true; //Sets exit value to true and closes the program
                            break;
                        default: //Default case if nothing is entered
                            System.out.println("Enter a valid command");
                    }
                } catch (Exception e) { //Catch statement if something breaks
                    System.out.println("Error");
                }
            }
        }
    }
}
