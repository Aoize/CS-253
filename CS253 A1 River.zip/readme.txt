Benjamin Sampson 914545

SOAP application built in Java 8 JDK

How to install/run the application:
Step1: After extracting the Zip file, open up NetBeans IDE.

Step2: Once inside NetBeans, click; File, Open Project, and navigate to "RiverA1" 

Step3: Once "RiverA1" has been opened, click; File, Open Project, and navigate to "RiverClient"

Step4: Once both "RiverA1" and "RiverClient" have been opened, right click on "RiverA1" and click "Deploy". This will deploy the Web Service Application. You can find this out by clicking on the "Output" box, then "RiverA1(run-deploy).

Step5: Once "RiverA1" has been deployed, right click on "RiverClient" and click "Run". This will then present you with a list of options that allow you to interact with the server.

Step6: Follow the commands given (e.g. addRiver) to create a river, add a tributary, update a rivers length, search for a river using the length, call all rivers, and exit the program. 