/**
 * @author Benjamin Sampson
 * 914545
 *
 * Java class that contains all the methods required to create and edit a river
 */
package river;

import java.util.ArrayList;

public class River {

    String name;
    int length;
    int tLength;
    ArrayList<River> tributaries; //ArrayList of tributaries

    /**
     * Constructor to make a river
     *
     * @param name
     * @param length
     */
    public River(String name, int length) {
        this.name = name;
        this.length = length;
        tributaries = new ArrayList<>();
    }

    /**
     * Sets the river name
     *
     * @param name
     */
    public void setRiverName(String name) {
        this.name = name;
    }

    /**
     * Gets the river name
     *
     * @return river name
     */
    public String getRiverName() {
        return name;
    }

    /**
     * Sets a river length
     *
     * @param length
     */
    public void setRiverLength(int length) {
        this.length = length;
    }

    /**
     * Gets a river length
     *
     * @return river length
     */
    public int getRiverLength() {
        return length;
    }

    /**
     * Method to get the total length with tributaries
     *
     * @return total length
     */
    public int totalRiverLength() {
        int totalLength;
        totalLength = this.getRiverLength();
        for (River r : tributaries) {
            totalLength += r.totalRiverLength();
        }
        return totalLength;
    }

    /**
     * Adds a tributary river
     *
     * @param river
     */
    public void addTributary(River river) {
        tributaries.add(river);
    }

    /**
     * toString to display the river name, length and tributary length
     *
     * @return river
     */
    @Override
    public String toString() {
        String river = this.getRiverName() + ", "
                + this.getRiverLength() + "km " + "("
                + this.totalRiverLength() + "km including tributaries) \n";
        return river;
    }
}
