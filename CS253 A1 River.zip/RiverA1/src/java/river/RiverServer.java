/**
 * @author Benjamin Sampson
 * 914545
 *
 * Java class that is the main server for the client, it calls river methods
 * and uses them to make or change a rivers atributes
 */
package river;

import java.util.ArrayList;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class RiverServer {

    private ArrayList<River> river = new ArrayList<>(); //ArrayList of rivers

    /**
     * Method used to create a river using a river name and length
     *
     * @param riverName gives the river inputted a name
     * @param length gives the river inputted a length
     * @return true if river has been added, false if not
     */
    @WebMethod
    public synchronized boolean addRiver(String riverName, int length) {
        River newRiver = new River(riverName, length);
        boolean sameRiver = false;
        ArrayList<River> clone = (ArrayList<River>) river.clone();
        for (River r : clone) {
            if (r.getRiverName().equals(newRiver.getRiverName())) {
                sameRiver = true;
            }
        }
        if (sameRiver == false) {
            river.add(newRiver);
            return true;
        }
        return false;
    }

    /**
     * Method that uses rivers created to add a tributary
     *
     * @param newRiver first river to be added
     * @param newRiver2 second river to be added
     * @return true if tributary has been added, false if not
     */
    @WebMethod
    public synchronized boolean makeTributary(String newRiver, String newRiver2) {
        River mainRiver = null;
        River tributaryRiver = null;
        ArrayList<River> clone = (ArrayList<River>) river.clone();
        for (River r : clone) {
            if (r.getRiverName().equalsIgnoreCase(newRiver)) {
                mainRiver = r;
            }
            if (r.getRiverName().equalsIgnoreCase(newRiver2)) {
                tributaryRiver = r;
            }
        }
        try {
            if (mainRiver != tributaryRiver && tributaryRiver != mainRiver) {
                mainRiver.addTributary(tributaryRiver);
                return true;
            }
        } catch (Exception e) {
            System.out.println("Cant make tributary!");
            return false;
        }
        return true;
    }

    /**
     * Private method that works with updateRiverLength to get a rivers name
     *
     * @param riverName river name
     * @return
     */
    @WebMethod
    private River getRivers(String riverName) {
        ArrayList<River> clone = (ArrayList<River>) river.clone();
        for (River r : clone) {
            if (r.getRiverName().equalsIgnoreCase(riverName)) {
                return r;
            }
        }
        return null;
    }

    /**
     * Method that gets the river name from getRivers name, then updates length
     *
     * @param riverName river name
     * @param newRiverLength new river length
     * @return return true if length updated, false if not
     */
    @WebMethod
    public synchronized boolean updateRiverLength(String riverName, int newRiverLength) {
        River r = getRivers(riverName);
        try {
            r.setRiverLength(newRiverLength);
        } catch (Exception e) {
            System.out.println("Can't update river's length!");
            return false;
        }
        return true;
    }

    /**
     * Method that searches for a river using only the rivers length
     *
     * @param searchRiver search length to go by
     * @return output which will be river with length >= length searched
     */
    @WebMethod
    public String searchRivers(int searchRiver) {
        ArrayList<River> clone = (ArrayList<River>) river.clone();
        String output = "";
        for (River r : clone) {
            if (r.totalRiverLength() >= searchRiver) {
                output += r.toString();
            } else if (r.totalRiverLength() <= searchRiver) {
                output += "Can't find river";
            }
        }
        return output;
    }

    /**
     * toString method that links to River.java to display all rivers
     *
     * @return all the rivers made
     */
    @WebMethod
    public String allRiversToString() {
        String allRivers = "";
        for (River r : river) {
            allRivers += r.toString();
        }
        return allRivers;
    }
}
