package river;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ben
 */
public class RiverMain {
    
    public static void main(String[] args){
//        RiverServer.addRiver("Danube", 2860);
//        RiverServer.addRiver("Isar", 287);           
//        RiverServer.addRiver("Inn", 517);   
//        
//        RiverServer.makeTributary("Danube", "Isar");
//        RiverServer.makeTributary("Danube", "Inn");
//        
//        RiverServer.updateRiverLength("Danube", 2859);
//                
//        System.out.println(RiverServer.getRivers("Isar").toString());
//        System.out.println(RiverServer.getRivers("Inn").toString());
//        System.out.println(RiverServer.getRivers("Danube").toString());

    }
    
}
