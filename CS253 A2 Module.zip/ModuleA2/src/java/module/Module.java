package module;

import java.util.ArrayList;
import javax.ejb.Singleton;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

/**
 * REST Web Service
 *
 * @author Benjamin Sampson 
 * 914545
 * 
 * Java class to add a module to a server, along with get the modules
 * using specific set of requests and change their discontinued status
 */
@Singleton
@Path("module")
public class Module {

    @Context
    private UriInfo context;
    private final ArrayList<JsonObject> modules = new ArrayList<>(); //Makes an array of modules

    /**
     * Creates a new instance of Module
     */
    public Module() {
    }

    /**
     * POST request method to add a module to the arrayList only if the module name
     * doesn't currently exsist
     * 
     * @param module module to be added
     * @return if the module exsists or is already added
     */
    @POST
    @Consumes("application/json")
    public String addModule(JsonObject module) {
        for (JsonObject m : modules) {
            if (m.getString("moduleName").equalsIgnoreCase(module.getString("moduleName"))) {
                return "Module exsists";
            }
        }
        modules.add(module);
        return "Added module";
    }

    /**
     * DELETE request method to delete a module using it's name only
     * 
     * @param moduleName name of the module to delete
     * @return if the module has been deleted
     */
    @DELETE
    @Path("{moduleName}")
    public synchronized String deleteModule(@PathParam("moduleName") String moduleName) {
        ArrayList<JsonObject> clone = (ArrayList<JsonObject>) modules.clone(); //Clones the arrayList
        for (JsonObject m : clone) { //Loops through the cloned array
            if (m.getJsonString("moduleName").getString().equalsIgnoreCase(moduleName)) {
                clone.remove(m); //Removes the module from the cloned array
                return "Module Deleted";
            }
        }
        return "Module Deleted";
    }

    /**
     * GET request to output all current modules
     * 
     * @param discontinued weather the module is discontinued or not
     * @return allModules that have been found if they are in the arrayList
     */
    @GET
    @Produces("text/plain")
    public synchronized String getModules(@DefaultValue("") @QueryParam("discontinued") String discontinued) {
        ArrayList<JsonObject> clone = (ArrayList<JsonObject>) modules.clone(); //Clones the arrayList
        String allModules = "";
        for (JsonObject m : clone) { //Loops through the cloned array
            if (discontinued.equalsIgnoreCase("Yes")) {
                if (m.getBoolean(discontinued) == true) { //If the module is discontinued
                    allModules += moduleToString(m); //Adds it to a string to output
                }
            } else if (discontinued.equalsIgnoreCase("No")) { 
                if (m.getBoolean(discontinued) == false) { //If the module is not discontinued
                    allModules += moduleToString(m); //Adds it to a string to output
                }
            } else { 
                allModules += moduleToString(m); //Adds it to a string to output
            }
        }
        return allModules; //Outputs all the modules found
    }

    /**
     * GET request to output a subject with it's module names
     * 
     * @param discontinued weather the module is discontinued or not
     * @param moduleDepartment the subject of the module (department)
     * @return moduleDep that have been found if they are in the arrayList
     */
    @GET
    @Path("{moduleDepartment}")
    @Produces("text/plain")
    public synchronized String getDepartment(@DefaultValue("") @QueryParam("discontinued") String discontinued,
            @PathParam("moduleDepartment") String moduleDepartment) {
        ArrayList<JsonObject> clone = (ArrayList<JsonObject>) modules.clone(); //Clones the arrayList
        String moduleDep = "";
        for (JsonObject m : clone) { //Loops through the cloned array
            if (discontinued.equalsIgnoreCase("Yes")) {
                if (m.getJsonString("moduleDepartment").getString().equalsIgnoreCase(moduleDepartment)
                        && m.getBoolean("discontinued") == true) { //If the department module is discontinued
                    moduleDep += moduleToString(m); //Adds it to a string to output
                } else if (discontinued.equalsIgnoreCase("No")) {
                    if (m.getJsonString("moduleDepartment").getString().equalsIgnoreCase(moduleDepartment)
                            && m.getBoolean("discontinued") == false) { //If the department module is not discontinued
                        moduleDep += moduleToString(m); //Adds it to a string to output
                    }
                } else { 
                    moduleDep += moduleToString(m); //Adds it to a string to output
                }
            }
        }
        return moduleDep; //Outputs all the department modules found
    }

    /**
     * GET request to output a subject and level of the module with the modules name
     * 
     * @param discontinued weather the module is discontinued or not
     * @param moduleDepartment the subject of the module (department)
     * @param moduleLevel the level of the module
     * @return  moduleDepLevel that have been found if they are in the arrayList
     */
    @GET
    @Path("{moduleDepartment}/{moduleLevel}")
    @Produces("text/plain")
    public synchronized String getModuleByDepLevel(@DefaultValue("") @QueryParam("discontinued") String discontinued,
            @PathParam("moduleDepartment") String moduleDepartment,
            @PathParam("moduleLevel") int moduleLevel) {
        ArrayList<JsonObject> clone = (ArrayList<JsonObject>) modules.clone(); //Clones the arrayList
        String moduleDepLevel = "";
        for (JsonObject m : clone) { //Loops through the cloned array
            if (discontinued.equalsIgnoreCase("Yes")) {
                if (m.getJsonString("moduleDepartment").getString().equalsIgnoreCase(moduleDepartment)
                        && m.getInt("moduleLevel") == (moduleLevel) && m.getBoolean("discontinued") == true) { //If the department module is discontinued
                    moduleDepLevel += moduleToString(m); //Adds it to a string to output
                }
            } else if (discontinued.equalsIgnoreCase("No")) {
                if (m.getJsonString("moduleDepartment").getString().equalsIgnoreCase(moduleDepartment)
                        && m.getInt("moduleLevel") == (moduleLevel) && m.getBoolean("discontinued") == false) { //If the department module is not discontinued
                    moduleDepLevel += moduleToString(m); //Adds it to a string to output
                }
            } else {
                moduleDepLevel += moduleToString(m); //Adds it to a string to output
            }
            moduleDepLevel += moduleToString(m); //Adds it to a string to output
        }
        return moduleDepLevel; //Outputs all the modules found by subject + level
    }

    /**
     * PUT request to change the discontinued status of modules to true or false
     * 
     * @param moduleName to change the status on
     * @return weather the module is found or not
     */
    @PUT
    @Consumes("text/plain")
    @Produces("text/plain")
    public synchronized String isDiscontinued(String moduleName) {
        ArrayList<JsonObject> clone = (ArrayList<JsonObject>) modules.clone(); //Loops through the cloned array
        for (JsonObject m : clone) {
            if (m.getJsonString("moduleName").getString().equals(moduleName)) {
                JsonObjectBuilder changeDiscontinued = Json.createObjectBuilder()
                        .add("modleName", m.getString("modleName"))
                        .add("moduleLevel", m.getInt("moduleLevel"))
                        .add("moduleDepartment", m.getString("moduleDepartment"));
                if (m.getBoolean("discontinued") == false) {
                    changeDiscontinued.add("discontinued", true); //Changes the status of discontinued to true
                } else {
                    changeDiscontinued.add("discontinued", false); //Changes the status of discontinued to false
                }
                clone.add(changeDiscontinued.build()); //Updates the modules changed
                return "Module found";
            }
        }
        return "Module not found";
    }

    /**
     * GET request to retrieve the toString to show all modules with their name,
     * department, level and discontinued status
     * 
     * @param m module to be outputted
     * @return moduleToString
     */
    @GET
    @Produces("text/plain")
    private String moduleToString(JsonObject m) {
        return "Module Name: " + m.getJsonString("moduleName").getString() + "\n"
                //+ "Department: " + m.getJsonString("moduleDepartment").getString() + "\n"
                // + "Discontinued: " + m.getBoolean("discontinued")
                + "Level: " + m.getInt("moduleLevel") + "\n";
    }
}
