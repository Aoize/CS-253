Benjamin Sampson 914545

REST application built in Java 8 JDK

How to install/run the application:
Step1: After extracting the Zip file, open up Netbeans IDE.

Step2: Once inside Netbeans, click; File, Open Project, and navigate to "ModuleA2"

Step3: Once "ModuleA2" has been opened, click; File, Open Project, and navigate to "ModuleClient"

Step4: Once both "ModuleA2" and "ModuleClient" have been opened, right click on "ModuleA2" and click "Deploy". This will deploy the Web Service Application. You can find this out by clicking on the "Output" box, then "ModuleA2(run-deploy).

Step5: Once "ModuleA2" has been deployed, right click on "ModuleClient" and click "Run". This will present you with a selection of pre-defined modules.

Step6: If you wish to make new modules, change values or test the program click; "Module" where you can enter commands to change values.