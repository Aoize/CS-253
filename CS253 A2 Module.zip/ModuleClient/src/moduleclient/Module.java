/**
 *
 * @author Benjamin Sampson
 * 914545
 * 
 * Java class that contains all the required information about a Module. 
 * This includes the Module name, department(subject), discontinued status
 * and the level of the Module. 
 */
package moduleclient;

public class Module {

    private String moduleName;
    private String moduleDepartment;
    private Boolean discontinued;
    private int moduleLevel;

    /**
     * Constructor to make a Module
     * 
     * @param mName name of the module
     * @param mDepartment department(subject) of the module
     * @param mDiscontinued discontinued status of the module
     * @param mLevel level of the module
     */
    public Module(String mName, String mDepartment, Boolean mDiscontinued, int mLevel) {
        this.moduleName = mName;
        this.moduleDepartment = mDepartment;
        this.discontinued = mDiscontinued;
        this.moduleLevel = mLevel;
    }

    public Module() {

    }

    /**
     * Method to set a module name
     * 
     * @param mName module name to be set
     */
    public void setModuleName(String mName) {
        moduleName = mName;
    }

    /**
     * Method to get a module name
     * 
     * @return moduleName
     */
    public String getModuleName() {
        return moduleName;
    }

    /**
     * Method to set a module department
     * 
     * @param mDepartment module department to be set
     */
    public void setModuleDep(String mDepartment) {
        moduleDepartment = mDepartment;
    }

    /**
     * Method to get a module department
     * 
     * @return moduleDepartment
     */
    public String getModuleDep() {
        return moduleDepartment;
    }

    /**
     * Method to set a module's discontinued status
     * 
     * @param mDiscontinued module discontinued status to be set
     */
    public void setDiscontinued(Boolean mDiscontinued) {
        discontinued = mDiscontinued;
    }

    /**
     * Method to get a module's discontinued status
     * 
     * @return discontinued
     */
    public boolean getDiscontinued() {
        return discontinued = false;
    }

    /**
     * Method to set a module's level
     * 
     * @param mLevel module level to be set
     */
    public void setModuleLevel(int mLevel) {
        moduleLevel = mLevel;
    }

    /**
     * Method to get a module's level
     * 
     * @return moduleLevel
     */
    public int getModuleLevel() {
        return moduleLevel;
    }

    /**
     * Method to output the information about a module
     * 
     * @return module
     */
    public String toString() {
        String module = this.getModuleName() + ", "
                + this.getModuleDep() + ", "
                + this.getDiscontinued() + ", "
                + this.getModuleLevel() + ", ";
        return module;
    }
}
