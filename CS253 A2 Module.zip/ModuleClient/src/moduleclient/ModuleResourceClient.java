package moduleclient;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;

/**
 * Jersey REST client generated for REST resource:Module [module]<br>
 * USAGE:
 * <pre>
 *        ModuleResourceClient client = new ModuleResourceClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author Benjamin Sampson 
 * 914545
 * 
 */
public class ModuleResourceClient {

    private WebTarget webTarget;
    private Client client;
    private static final String BASE_URI = "http://localhost:8080/ModuleA2/webresources";

    public ModuleResourceClient() {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("module");
    }

    public String getDepartment(String moduleDepartment, String discontinued) throws ClientErrorException {
        WebTarget resource = webTarget;
        if (discontinued != null) {
            resource = resource.queryParam("discontinued", discontinued);
        }
        resource = resource.path(java.text.MessageFormat.format("{0}", new Object[]{moduleDepartment}));
        return resource.request(javax.ws.rs.core.MediaType.TEXT_PLAIN).get(String.class);
    }

    public String getModules(String discontinued) throws ClientErrorException {
        WebTarget resource = webTarget;
        if (discontinued != null) {
            resource = resource.queryParam("discontinued", discontinued);
        }
        return resource.request(javax.ws.rs.core.MediaType.TEXT_PLAIN).get(String.class);
    }

    public String isDiscontinued(Object requestEntity) throws ClientErrorException {
        return webTarget.request(javax.ws.rs.core.MediaType.TEXT_PLAIN).put(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.TEXT_PLAIN), String.class);
    }

    public String getModuleByDepLevel(String moduleDepartment, String moduleLevel, String discontinued) throws ClientErrorException {
        WebTarget resource = webTarget;
        if (discontinued != null) {
            resource = resource.queryParam("discontinued", discontinued);
        }
        resource = resource.path(java.text.MessageFormat.format("{0}/{1}", new Object[]{moduleDepartment, moduleLevel}));
        return resource.request(javax.ws.rs.core.MediaType.TEXT_PLAIN).get(String.class);
    }

    public String moduleToString() throws ClientErrorException {
        WebTarget resource = webTarget;
        return resource.request(javax.ws.rs.core.MediaType.TEXT_PLAIN).get(String.class);
    }

    public String addModule(Object requestEntity) throws ClientErrorException {
        return webTarget.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).post(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.APPLICATION_JSON), String.class);
    }

    public String deleteModule(String moduleName) throws ClientErrorException {
        return webTarget.path(java.text.MessageFormat.format("{0}", new Object[]{moduleName})).request().delete(String.class);
    }

    public void close() {
        client.close();
    }
    
}
