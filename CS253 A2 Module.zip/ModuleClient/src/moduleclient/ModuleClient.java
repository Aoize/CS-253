package moduleclient;

/**
 *
 * @author Benjamin Sampson
 * 914545
 * 
 * Main class to create the client and perform operations linked to the Module Server
 * 
 * From last assignment, I have listened to feedback and made sure to synchronise 
 * all of my methods that make use of the cloning feature. I have also made sure
 * that all my declarations across the classes have been made private, along with
 * all my methods being private, as I lacked on this in the last assignment.
 */
public class ModuleClient {

    public static void main(String[] args) {
        //Creates a client
        ModuleResourceClient client = new ModuleResourceClient();

        //Adds new modules
        Module module = new Module("ICT", "Computing", true, 2);
        client.addModule(module);

        Module module1 = new Module("Biology", "Science", false, 3);
        client.addModule(module1);

        //Getting all added modues
        System.out.println(client.getModules(""));

    }
}
